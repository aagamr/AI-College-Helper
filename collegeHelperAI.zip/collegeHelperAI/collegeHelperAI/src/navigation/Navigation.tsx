import React from 'react';
import {Image, StyleSheet} from 'react-native';
import {createStackNavigator} from '@react-navigation/stack';
import {AnimatedTabBarNavigator} from 'react-native-animated-nav-tab-bar';

import Home from '../screens/home/Home';
import Profile from '../screens/components/Profile';
import LoginChecker from '../screens/LoginChecker';
import Welcome from '../screens/Welcome';
import Chooser from '../screens/Chooser';
import PdfSummary from '../screens/components/PdfSummary';
import YoutubeSummary from '../screens/components/YoutubeSummary';
import ImageSummary from '../screens/components/ImageSummary';
import PdfToQuiz from '../screens/components/PdfToQuiz';
import AskQuestion from '../screens/components/AskQuestion';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';

import HomeIcon from '../assets/images/home.png';
import HomeIconFocused from '../assets/images/home-outline.png'; // Focused icon if available
import ProfileIcon from '../assets/images/profile-outline.png';
import ProfileIconFocused from '../assets/images/profile.png'; // Focused icon if available
import SolveIcon from '../assets/images/solve-outline.png'; // Focused icon if available
import SolveIconFocused from '../assets/images/solve.png'; // Focused icon if available

import Solve from '../screens/solve/Solve';
import Solution from '../screens/solve/Solution';
import FlashCard from '../screens/flash/FlashCard';

const Stack = createStackNavigator();
const Tabs = AnimatedTabBarNavigator();

export const Tab = () => (
  <Tabs.Navigator
    screenOptions={{headerShown: false}}
    initialRouteName="Home"
    appearance={{
      tabBarBackground: '#111827',
      activeTabBackgrounds: ['#1d2639', '#1d2639', '#1d2639'],
    }}
    tabBarOptions={{
      labelStyle: {
        fontFamily: 'Poppins-SemiBold',
        color: 'white',
      },
      tabStyle: {
        // borderTopWidth: 1,
        // borderColor: '#444444',
      },
    }}>
    <Tabs.Screen
      name="Solve"
      component={Solve}
      options={{
        tabBarIcon: ({focused}) => (
          <Image source={focused ? SolveIcon : SolveIcon} style={styles.icon} />
        ),
      }}
    />
    <Tabs.Screen
      name="Home"
      component={Home}
      options={{
        tabBarIcon: ({focused}) => (
          <Image source={focused ? HomeIcon : HomeIcon} style={styles.icon} />
        ),
      }}
    />
    <Tabs.Screen
      name="Profile"
      component={Profile}
      options={{
        tabBarIcon: ({focused}) => (
          <Image
            source={focused ? ProfileIcon : ProfileIcon}
            style={styles.icon}
          />
        ),
      }}
    />
  </Tabs.Navigator>
);

const Navigation = () => {
  return (
    <Stack.Navigator screenOptions={{headerShown: false}}>
      <Stack.Screen name="logincheck" component={LoginChecker} />
      <Stack.Screen name="welcome" component={Welcome} />
      <Stack.Screen name="chooser" component={Chooser} />
      <Stack.Screen name="HomeTabs" component={Tab} />
      <Stack.Screen name="pdf" component={PdfSummary} />
      <Stack.Screen name="solve" component={Solve} />
      <Stack.Screen name="solution" component={Solution} />
      <Stack.Screen name="yt" component={YoutubeSummary} />
      <Stack.Screen name="image" component={ImageSummary} />
      <Stack.Screen name="quiz" component={PdfToQuiz} />
      <Stack.Screen name="ask" component={AskQuestion} />
      <Stack.Screen name="profile" component={Profile} />
      <Stack.Screen name="flash" component={FlashCard} />
    </Stack.Navigator>
  );
};

export default Navigation;

const styles = StyleSheet.create({
  icon: {
    width: 20,
    height: 20,
    resizeMode: 'contain',
  },
});
