import React, {useContext, useState, useRef} from 'react';
import {
  Animated,
  Image,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  ToastAndroid,
  TouchableOpacity,
  View,
  Dimensions,
} from 'react-native';
import {UserContext} from '../../context/UserContext';
import {Bell, Search, TrendingUp} from 'lucide-react-native';

const {width} = Dimensions.get('window');

const Home = ({navigation}) => {
  const [disabled, setDisabled] = useState(true);
  const [scale] = useState(new Animated.Value(1));
  const {user} = useContext(UserContext);
  const scrollY = useRef(new Animated.Value(0)).current;

  const getGreeting = () => {
    const currentHour = new Date().getHours();
    if (currentHour < 12) return 'Good Morning';
    else if (currentHour < 18) return 'Good Afternoon';
    else return 'Good Evening';
  };

  // Animated header opacity based on scroll
  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [1, 0.9],
    extrapolate: 'clamp',
  });

  const handlePressIn = () => {
    Animated.spring(scale, {
      toValue: 0.95,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    Animated.spring(scale, {
      toValue: 1,
      friction: 3,
      tension: 40,
      useNativeDriver: true,
    }).start();
  };

  const handleScroll = Animated.event(
    [{nativeEvent: {contentOffset: {y: scrollY}}}],
    {useNativeDriver: true},
  );

  const renderCard = (text1, text2, image, navigateTo, isDisabled = false) => (
    <TouchableOpacity
      style={[styles.card, isDisabled && styles.cardDisabled]}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      disabled={isDisabled}
      onPress={() => navigation.navigate(navigateTo)}>
      <Animated.View style={[styles.cardContent, {transform: [{scale}]}]}>
        <Image resizeMode="contain" style={styles.cardImage} source={image} />
        <View style={styles.cardTextContainer}>
          <Text style={styles.cardText}>{text1}</Text>
          <Text style={styles.cardText}>{text2}</Text>
        </View>
      </Animated.View>
    </TouchableOpacity>
  );

  const renderQuickStats = () => (
    <View style={styles.statsContainer}>
      <View style={styles.statCard}>
        <TrendingUp color="#4ADE80" size={20} />
        <Text style={styles.statNumber}>0</Text>
        <Text style={styles.statLabel}>Questions Asked</Text>
      </View>
      <View style={styles.statCard}>
        <Image
          source={require('../../assets/images/cards.png')}
          style={styles.statIcon}
        />
        <Text style={styles.statNumber}>0</Text>
        <Text style={styles.statLabel}>Flashcards Created</Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <Animated.View style={[styles.header, {opacity: headerOpacity}]}>
        <View style={styles.headerContent}>
          <View style={styles.userSection}>
            <TouchableOpacity style={styles.profileButton}>
              <Image
                style={styles.profileImage}
                source={{uri: user?.photoURL}}
              />
            </TouchableOpacity>
            <View style={styles.greetingContainer}>
              <Text style={styles.greeting}>{getGreeting()}</Text>
              <Text style={styles.username}>{user?.displayName}</Text>
            </View>
          </View>

          <View style={styles.headerButtons}>
            {/* <TouchableOpacity
              style={styles.iconButton}
              onPress={() => navigation.navigate('search')}>
              <Search color="#FFFFFF" size={22} />
            </TouchableOpacity> */}
            <TouchableOpacity
              style={styles.iconButton}
              onPress={() =>
                ToastAndroid.show('No New Notifications', ToastAndroid.SHORT)
              }>
              <Bell color="#FFFFFF" size={22} />
            </TouchableOpacity>
          </View>
        </View>

        <TouchableOpacity
          style={styles.searchBar}
          onPress={() => navigation.navigate('ask')}>
          <Search color="#9CA3AF" size={20} />
          <Text style={styles.searchPlaceholder}>Search your questions...</Text>
        </TouchableOpacity>
      </Animated.View>

      <Animated.ScrollView
        contentContainerStyle={styles.contentContainer}
        onScroll={handleScroll}
        scrollEventThrottle={16}
        showsVerticalScrollIndicator={false}>
        {/* {renderQuickStats()} */}

        {/* <Text style={styles.sectionTitle}>AI Tools</Text> */}
        <View style={styles.grid}>
          {renderCard(
            'PPT / PDF',
            'Summary',
            require('../../assets/images/pdf.png'),
            'pdf',
          )}
          {renderCard(
            'Image',
            'Explain',
            require('../../assets/images/image-explain.png'),
            'image',
          )}
          {renderCard(
            'Flash',
            'Cards',
            require('../../assets/images/flash.png'),
            'flash',
          )}
          {renderCard(
            'PDF to',
            'Quiz',
            require('../../assets/images/quiz.png'),
            'quiz',
          )}
          {renderCard(
            'Video',
            'Summary',
            require('../../assets/images/video.png'),
            'video',
            disabled,
          )}
        </View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  header: {
    padding: 20,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#374151',
    backgroundColor: '#111827',
    zIndex: 1,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  userSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  profileButton: {
    borderWidth: 2,
    borderColor: '#ffffff',
    height: 50,
    width: 50,
    backgroundColor: '#1F2937',
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 4,
  },
  profileImage: {
    height: 45,
    width: 45,
    borderRadius: 22.5,
  },
  greetingContainer: {
    gap: 4,
  },
  greeting: {
    color: '#9CA3AF',
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
  },
  username: {
    color: '#F3F4F6',
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
  },
  headerButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  iconButton: {
    padding: 8,
    borderRadius: 12,
    backgroundColor: '#1F2937',
    elevation: 2,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1F2937',
    borderRadius: 12,
    padding: 12,
    gap: 8,
  },
  searchPlaceholder: {
    color: '#9CA3AF',
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    flex: 1,
  },
  contentContainer: {
    padding: 20,
    paddingBottom: 40,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#1F2937',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#374151',
  },
  statIcon: {
    width: 20,
    height: 20,
    tintColor: '#4ADE80',
    transform: [{rotate: '180deg'}],
  },
  statNumber: {
    color: '#F3F4F6',
    fontFamily: 'Poppins-SemiBold',
    fontSize: 24,
    marginTop: 8,
  },
  statLabel: {
    color: '#9CA3AF',
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    marginTop: 4,
  },
  sectionTitle: {
    color: '#F3F4F6',
    fontFamily: 'Poppins-SemiBold',
    fontSize: 20,
    marginBottom: 16,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
    justifyContent: 'space-between',
    marginTop: 4,
  },
  card: {
    width: (width - 56) / 2,
    height: 180,
    // borderWidth: 1,
    // borderColor: '#374151',
    borderRadius: 16,
    backgroundColor: '#1F2937',
    padding: 1,
  },
  cardDisabled: {
    backgroundColor: '#374151',
    opacity: 0.5,
  },
  cardContent: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardImage: {
    width: 60,
    height: 60,
    marginBottom: 12,
  },
  cardTextContainer: {
    alignItems: 'center',
  },
  cardText: {
    fontFamily: 'Poppins-Regular',
    color: '#F3F4F6',
    fontSize: 14,
    textAlign: 'center',
  },
});

export default Home;
