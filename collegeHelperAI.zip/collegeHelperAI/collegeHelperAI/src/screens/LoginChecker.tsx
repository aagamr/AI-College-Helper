// LoginChecker.tsx
import React, {useContext, useEffect, useRef} from 'react';

import {UserContext} from '../context/UserContext';
import {Text} from 'react-native';

const LoginChecker = ({navigation}: any) => {
  const {user} = useContext(UserContext);
  const isInitialRender = useRef(true);

  useEffect(() => {
    if (!isInitialRender.current) {
      if (!user) {
        navigation.replace('welcome');
      } else {
        navigation.replace('HomeTabs');
      }
    }
  }, [user]);

  useEffect(() => {
    isInitialRender.current = false;
  }, []);

  return navigation.replace('welcome');
};

export default LoginChecker;
