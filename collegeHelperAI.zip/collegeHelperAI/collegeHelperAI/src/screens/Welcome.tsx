import React, {useEffect, useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  ImageBackground,
  StatusBar,
} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import Swiper from 'react-native-swiper';
import LottieView from 'lottie-react-native';

const slides = [
  {
    key: '1',
    text: 'Overwhelmed by last-minute PDFs before exams? Let our AI summarize them for you quickly!',
    image: require('../assets/animation/Animation1.json'),
  },
  {
    key: '2',
    text: 'Struggling with understanding complex diagrams? We provide clear, easy-to-follow explanations.',
    image: require('../assets/animation/Animation2.json'),
  },
  {
    key: '3',
    text: 'Need to test your knowledge fast? Our AI generates quizzes from your PDFs to help you review effectively.',
    image: require('../assets/animation/Animation3.json'),
  },
];

const Welcome = ({navigation}: any) => {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const handleNextPress = () => {
    if (currentSlideIndex < slides.length - 1 && swiperRef) {
      swiperRef.scrollBy(1);
    } else {
      navigation.replace('chooser');
    }
  };

  let swiperRef: Swiper | null;

  return (
    <SafeAreaView style={styles.container}>
      <Swiper
        loop={false}
        showsPagination={true}
        activeDotColor="#3B82F6"
        dotColor="#4B5563"
        paginationStyle={styles.pagination}
        dotStyle={styles.dot}
        activeDotStyle={styles.activeDot}
        onIndexChanged={index => setCurrentSlideIndex(index)}
        ref={ref => (swiperRef = ref)}>
        {slides.map(slide => (
          <View key={slide.key} style={styles.slide}>
            <ImageBackground
              source={require('../assets/images/dot.jpeg')}
              style={styles.imageBackground}
              imageStyle={styles.imageBackgroundImage}>
              <LottieView
                source={slide.image}
                autoPlay
                style={{height: 300, width: 300}}
                speed={1}
                loop
              />
            </ImageBackground>
            <Text style={styles.text}>{slide.text}</Text>
          </View>
        ))}
      </Swiper>

      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.nextButton} onPress={handleNextPress}>
          <Text style={styles.nextButtonText}>
            {currentSlideIndex === slides.length - 1 ? 'Get Started' : 'Next'}
          </Text>
        </TouchableOpacity>
      </View>
      <TouchableOpacity
        style={styles.skipButton}
        onPress={() => navigation.replace('chooser')}>
        <Text style={styles.skipButtonText}>Skip</Text>
      </TouchableOpacity>
      <StatusBar barStyle="light-content" />
    </SafeAreaView>
  );
};

export default Welcome;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827', // Updated to match FlashCard dark background
  },
  slide: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    marginHorizontal: 20,
  },
  imageBackground: {
    width: 300,
    height: 300,
    justifyContent: 'center',
    backgroundColor: '#fff', // Updated to match FlashCard secondary background
    alignItems: 'center',
    borderRadius: 200,
    marginBottom: 40,
    borderWidth: 1,
    borderColor: '#374151', // Updated to match FlashCard border color
  },
  imageBackgroundImage: {
    resizeMode: 'cover',
    borderRadius: 200,
    opacity: 0.4,
  },
  text: {
    fontSize: 20,
    color: '#F3F4F6', // Updated to match FlashCard text color
    textAlign: 'center',
    fontFamily: 'Poppins-Medium',
    paddingHorizontal: 10,
  },
  buttonContainer: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  nextButton: {
    backgroundColor: '#3B82F6', // Updated to match FlashCard primary button color
    borderRadius: 12, // Updated to match FlashCard button radius
    paddingVertical: 15,
    width: '50%',
    paddingHorizontal: 25,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 40,
    borderWidth: 0, // Removed border to match FlashCard style
    marginBottom: 60,
  },
  nextButtonText: {
    color: '#FFFFFF', // Updated to white to match FlashCard button text
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
  },
  skipButton: {
    position: 'absolute',
    top: 30,
    right: 20,

    padding: 8,
    borderRadius: 8,
  },
  skipButtonText: {
    color: '#9CA3AF', // Updated to match FlashCard secondary text color
    fontSize: 14,
    fontFamily: 'Poppins-Medium',
  },
  pagination: {
    bottom: 60,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginTop: 10,
    backgroundColor: '#4B5563', // Updated to match FlashCard secondary color
  },
  activeDot: {
    width: 8,
    height: 8,
    marginTop: 10,
    borderRadius: 4,
    backgroundColor: '#3B82F6', // Updated to match FlashCard primary color
  },
});
