import React, {useState} from 'react';
import {
  StyleSheet,
  View,
  Image,
  TouchableOpacity,
  Text,
  Alert,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import {GoogleGenerativeAI} from '@google/generative-ai';
import MarkdownDisplay from 'react-native-markdown-display';

const Solution = ({route, navigation}: any) => {
  const {base64Image} = route.params;
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [prompt, setPrompt] = useState(
    'Solve this Question attached in the image and give detailed steps.',
  );

  const submitImage = async () => {
    setLoading(true);
    try {
      const genAI = new GoogleGenerativeAI(
        'AIzaSyCIQHteF8oLMgI5dvrI7d5e4C82Iqg3b1o',
      );

      const model = genAI.getGenerativeModel({model: 'gemini-1.5-flash'});

      // Format the image data for Gemini
      const imageData = {
        inlineData: {
          data: base64Image,
          mimeType: 'image/jpeg',
        },
      };

      try {
        const result = await model.generateContent([prompt, imageData]);

        const response = await result.response;
        const generatedText = response.text();
        setDescription(generatedText);
      } catch (error) {
        console.error('Error generating content:', error);
        Alert.alert('Error', 'Unable to generate solution. Please try again.');
      }
    } catch (error) {
      console.error('Error uploading image:', error);
      Alert.alert('Error', 'Failed to process image. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.scrollView}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <View style={{padding: 20}}>
          <Image
            style={{width: 40, height: 40}}
            source={require('../../assets/images/left-arrow.png')}
          />
        </View>
      </TouchableOpacity>

      <View style={styles.container}>
        {base64Image && (
          <Image
            source={{uri: `data:image/jpeg;base64,${base64Image}`}}
            style={styles.image}
            resizeMode="contain"
          />
        )}

        <TouchableOpacity
          style={[styles.button, loading && styles.buttonDisabled]}
          onPress={submitImage}
          disabled={loading}>
          {loading ? (
            <ActivityIndicator color="white" />
          ) : (
            <Text style={styles.buttonText}>Get Solution</Text>
          )}
        </TouchableOpacity>

        {description ? (
          <View style={styles.solutionContainer}>
            <Text style={styles.solutionTitle}>Solution:</Text>
            <MarkdownDisplay style={styles.markdown}>
              {description}
            </MarkdownDisplay>
          </View>
        ) : null}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scrollView: {
    flex: 1,
    backgroundColor: '#1F1F1F',
  },
  container: {
    flex: 1,
    alignItems: 'center',
    padding: 20,
  },
  image: {
    width: '100%',
    height: 300,
    marginBottom: 20,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#333',
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 6,
    shadowOffset: {width: 0, height: 3},
  },
  button: {
    backgroundColor: '#007BFF',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 10,
    width: '80%',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 4,
    shadowOffset: {width: 0, height: 2},
  },
  buttonDisabled: {
    backgroundColor: '#555',
  },
  buttonText: {
    color: '#FFF',
    fontSize: 18,
    fontFamily: 'Poppins-Medium',
  },
  solutionContainer: {
    marginTop: 20,
    width: '100%',
    padding: 16,
    backgroundColor: '#2B2B2B',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 5,
    shadowOffset: {width: 0, height: 3},
  },
  solutionTitle: {
    fontSize: 20,
    color: '#E5E5E5',
    fontFamily: 'Poppins-Bold',
    marginBottom: 10,
  },
  markdown: {
    body: {
      fontSize: 16,
      fontFamily: 'Poppins-Regular',
      lineHeight: 24,
      color: '#D3D3D3',
    },
  },
});

export default Solution;
