import React, {useRef, useState} from 'react';
import {StyleSheet, View, TouchableOpacity, Text, Image} from 'react-native';
import {RNCamera} from 'react-native-camera';
import ImageResizer from 'react-native-image-resizer';
import ImageCropPicker from 'react-native-image-crop-picker';
import RNFS from 'react-native-fs';

const Solve = ({navigation}) => {
  const cameraRef = useRef<RNCamera | null>(null);
  const [flashMode, setFlashMode] = useState(RNCamera.Constants.FlashMode.off);

  const toggleFlash = () => {
    setFlashMode(prevFlashMode =>
      prevFlashMode === RNCamera.Constants.FlashMode.off
        ? RNCamera.Constants.FlashMode.on
        : RNCamera.Constants.FlashMode.off,
    );
  };

  const captureImage = async () => {
    if (cameraRef.current) {
      const options = {quality: 0.8, base64: true, flashMode};
      const data = await cameraRef.current.takePictureAsync(options);

      try {
        const resizedImage = await ImageResizer.createResizedImage(
          data.uri,
          1200,
          800,
          'JPEG',
          80,
        );
        const croppedImage = await ImageCropPicker.openCropper({
          path: resizedImage.uri,
          compressImageQuality: 0.8,
          includeBase64: true,
          freeStyleCropEnabled: true,
          mediaType: 'photo',
        });

        const base64Image = croppedImage.data;
        navigation.navigate('solution', {base64Image});
      } catch (error) {
        console.log('Error resizing or cropping image:', error);
      }
    }
  };

  const selectImageFromGallery = async () => {
    try {
      const image = await ImageCropPicker.openPicker({
        cropping: true,
        freeStyleCropEnabled: true, // Enable free style cropping
        includeBase64: true, // Return base64 in the response
      });

      const base64Image = image.data; // Get the base64 image directly from the response
      navigation.navigate('solution', {base64Image});
    } catch (error) {
      console.log('Error selecting image from gallery:', error);
    }
  };

  return (
    <View style={styles.container}>
      <RNCamera
        ref={cameraRef}
        style={StyleSheet.absoluteFill}
        type={RNCamera.Constants.Type.back}
        flashMode={flashMode}
        captureAudio={false}
      />
      <View style={styles.overlay}>
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={styles.button}
            onPress={selectImageFromGallery}>
            <Image
              style={styles.icon}
              source={require('../../assets/images/gallery.png')}
            />
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={captureImage}>
            <Image
              style={{width: 60, height: 60}}
              source={require('../../assets/images/solve-camera.png')}
            />
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={toggleFlash}>
            <Image
              style={styles.icon}
              source={
                flashMode === RNCamera.Constants.FlashMode.on
                  ? require('../../assets/images/flashlight-on.png')
                  : require('../../assets/images/flashlight-off.png')
              }
            />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  overlay: {
    position: 'absolute',
    bottom: 30,
    width: '100%',
    alignItems: 'center',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '70%', // Adjust this width as needed
  },
  button: {
    alignItems: 'center',
    marginHorizontal: 10, // Add horizontal spacing between buttons
  },
  icon: {
    width: 35,
    height: 35,
  },
  buttonText: {
    fontSize: 16,
    color: 'white',
    fontFamily: 'Poppins-Regular',
  },
});

export default Solve;
