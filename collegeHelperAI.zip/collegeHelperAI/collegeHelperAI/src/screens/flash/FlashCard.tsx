import React, {useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  Alert,
  ToastAndroid,
  Image,
  ScrollView,
  SafeAreaView,
  Dimensions,
} from 'react-native';
import FlipCard from 'react-native-flip-card';
import DocumentPicker from 'react-native-document-picker';
import RNFS from 'react-native-fs';
import {GoogleGenerativeAI} from '@google/generative-ai';
import {
  Upload,
  ChevronLeft,
  ChevronRight,
  Plus,
  File,
} from 'lucide-react-native';
const {width: SCREEN_WIDTH} = Dimensions.get('window');
const CARD_WIDTH = SCREEN_WIDTH - 40; // 40 accounts for container padding (20 on each side)
const FlashCardScreen = ({navigation}: {navigation: any}) => {
  const [question, setQuestion] = useState('');
  const [flashcards, setFlashcards] = useState([
    {
      question: 'What is the largest planet in our solar system?',
      answer: 'Jupiter',
    },
    {question: 'What is the capital city of France?', answer: 'Paris'},
  ]);
  const [loading, setLoading] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [file, setFile] = useState(null);
  const apiKeys = [
    process.env.API_KEY1,
    process.env.API_KEY2,
    process.env.API_KEY3,
    process.env.API_KEY4,
    process.env.API_KEY5,
    process.env.API_KEY6,
  ];
  const selectedApiKey = apiKeys[Math.floor(Math.random() * apiKeys.length)];
  const handleFilePick = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.allFiles, DocumentPicker.types.images],
      });
      setFile(result[0]);
      handleFileUpload(result[0]);
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
        console.log('User cancelled the picker');
      } else {
        throw err;
      }
    }
  };

  const handleFileUpload = async selectedFile => {
    if (selectedFile) {
      setLoading(true);
      try {
        const base64File = await RNFS.readFile(selectedFile.uri, 'base64');
        const genAI = new GoogleGenerativeAI(selectedApiKey || '');
        const model = genAI.getGenerativeModel({model: 'gemini-1.5-flash'});

        const filePart = {
          inlineData: {
            data: base64File,
            mimeType: selectedFile.type,
          },
        };

        const prompt = `Read this file and generate 10 flashcards from its content. 
          Each flashcard should have a question and answer. 
          Return the response as a JSON array of objects with 'question' and 'answer' properties.
          Format: [{"question": "...", "answer": "..."}, ...]`;

        const result = await model.generateContent([prompt, filePart]);
        const generatedText = result.response.text();
        const cleanResponse = generatedText
          .replace(/```json/g, '')
          .replace(/```/g, '')
          .trim();
        const parsedFlashcards = JSON.parse(cleanResponse);

        if (Array.isArray(parsedFlashcards)) {
          setFlashcards(parsedFlashcards);
          setCurrentIndex(0);
          ToastAndroid.show(
            'Flashcards Generated Successfully',
            ToastAndroid.SHORT,
          );
        }
      } catch (error) {
        console.error('Error processing file:', error);
        Alert.alert('Error', 'An error occurred while processing the file.');
      } finally {
        setLoading(false);
      }
    }
  };

  const handleAskQuestion = async () => {
    if (!question.trim()) {
      Alert.alert('Please enter a question.');
      return;
    }

    setLoading(true);
    try {
      const genAI = new GoogleGenerativeAI(
        'AIzaSyCIQHteF8oLMgI5dvrI7d5e4C82Iqg3b1o',
      );
      const model = genAI.getGenerativeModel({model: 'gemini-1.5-flash'});
      const prompt = `Generate 10 flashcards related to: ${question}. Return as JSON array with question and answer properties.`;

      const result = await model.generateContent(prompt);
      const generatedText = result.response.text();
      const cleanResponse = generatedText
        .replace(/```json/g, '')
        .replace(/```/g, '')
        .trim();

      const parsedFlashcards = JSON.parse(cleanResponse);

      if (Array.isArray(parsedFlashcards)) {
        setFlashcards(parsedFlashcards);
        setCurrentIndex(0);
        setQuestion('');
        ToastAndroid.show(
          'Flashcards Generated Successfully',
          ToastAndroid.SHORT,
        );
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to generate flashcards. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleNext = () => {
    if (currentIndex < flashcards.length - 1) setCurrentIndex(currentIndex + 1);
  };

  const handlePrevious = () => {
    if (currentIndex > 0) setCurrentIndex(currentIndex - 1);
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {/* <View style={styles.header}>
          <Text style={styles.title}>Flashcards</Text>
          <Text style={styles.subtitle}>Learn anything, anywhere</Text>
        </View> */}
        <View style={styles.header}>
          <TouchableOpacity
            onPress={() => navigation.navigate('HomeTabs')}
            style={styles.backButton}>
            <Image
              resizeMode="contain"
              style={styles.backIcon}
              source={require('../../assets/images/left-arrow.png')}
            />
          </TouchableOpacity>
          <View style={styles.headerTextContainer}>
            <Text style={styles.title}>Flashcards</Text>
            <Text style={styles.subtitle}>Learn anything, anywhere</Text>
          </View>
        </View>

        <View style={styles.inputSection}>
          <TextInput
            placeholder="What would you like to learn about?"
            placeholderTextColor="#9CA3AF"
            style={styles.input}
            multiline
            value={question}
            onChangeText={setQuestion}
          />
          <TouchableOpacity
            style={[
              styles.generateButton,
              loading && styles.generateButtonDisabled,
            ]}
            onPress={handleAskQuestion}
            disabled={loading}>
            <Plus color="#FFFFFF" size={24} />
            <Text style={styles.generateButtonText}>
              {loading ? 'Generating...' : 'Create Flashcards'}
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.divider}>
          <View style={styles.line} />
          <Text style={styles.dividerText}>OR</Text>
          <View style={styles.line} />
        </View>

        <TouchableOpacity style={styles.uploadButton} onPress={handleFilePick}>
          <Upload color="#FFFFFF" size={24} />
          <Text style={styles.uploadButtonText}>
            {loading ? 'Processing...' : 'Upload Study Material'}
          </Text>
        </TouchableOpacity>

        {file && (
          <View style={styles.fileInfo}>
            <File color="#A5C3C4" size={20} />
            <Text style={styles.fileName}>{file.name}</Text>
            {file.type.startsWith('image/') && (
              <Image source={{uri: file.uri}} style={styles.previewImage} />
            )}
          </View>
        )}

        {flashcards.length > 0 && (
          <View style={styles.cardSection}>
            <FlipCard
              style={[styles.card, {width: CARD_WIDTH}]}
              friction={6}
              perspective={1000}
              flipHorizontal
              flipVertical={false}
              clickable>
              <View style={styles.cardFace}>
                <Text style={styles.cardLabel}>QUESTION</Text>
                <View style={styles.cardContentWrapper}>
                  <ScrollView
                    style={styles.cardScrollView}
                    contentContainerStyle={styles.cardContentContainer}
                    showsVerticalScrollIndicator={true}>
                    <Text style={styles.cardText}>
                      {flashcards[currentIndex].question}
                    </Text>
                  </ScrollView>
                </View>
                <Text style={styles.tapHint}>Tap to flip</Text>
              </View>
              <View style={styles.cardBack}>
                <Text style={styles.cardLabel}>ANSWER</Text>
                <View style={styles.cardContentWrapper}>
                  <ScrollView
                    style={styles.cardScrollView}
                    contentContainerStyle={styles.cardContentContainer}
                    showsVerticalScrollIndicator={true}>
                    <Text style={styles.cardText}>
                      {flashcards[currentIndex].answer}
                    </Text>
                  </ScrollView>
                </View>
                <Text style={styles.tapHint}>Tap to flip back</Text>
              </View>
            </FlipCard>

            <View style={styles.navigation}>
              <TouchableOpacity
                style={[
                  styles.navButton,
                  currentIndex === 0 && styles.navButtonDisabled,
                ]}
                onPress={handlePrevious}
                disabled={currentIndex === 0}>
                <ChevronLeft
                  color={currentIndex === 0 ? '#6B7280' : '#60A5FA'}
                  size={24}
                />
              </TouchableOpacity>

              <Text style={styles.cardCount}>
                {currentIndex + 1} of {flashcards.length}
              </Text>

              <TouchableOpacity
                style={[
                  styles.navButton,
                  currentIndex === flashcards.length - 1 &&
                    styles.navButtonDisabled,
                ]}
                onPress={handleNext}
                disabled={currentIndex === flashcards.length - 1}>
                <ChevronRight
                  color={
                    currentIndex === flashcards.length - 1
                      ? '#6B7280'
                      : '#60A5FA'
                  }
                  size={24}
                />
              </TouchableOpacity>
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  scrollContainer: {
    padding: 20,
  },
  header: {
    marginBottom: 32,
  },
  headerTextContainer: {
    alignItems: 'center',
    marginTop: 16,
  },
  backButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#1F2937',
    alignSelf: 'flex-start',
  },
  backIcon: {
    width: 24,
    height: 24,
    tintColor: '#FFFFFF',
  },
  title: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#F3F4F6',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    color: '#9CA3AF',
  },
  inputSection: {
    marginBottom: 24,
  },
  input: {
    backgroundColor: '#1F2937',
    color: '#F3F4F6',
    padding: 16,
    borderRadius: 12,
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#374151',
  },
  generateButton: {
    backgroundColor: '#3B82F6',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    gap: 8,
  },
  generateButtonDisabled: {
    backgroundColor: '#6B7280',
  },
  generateButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 24,
  },
  line: {
    flex: 1,
    height: 1,
    backgroundColor: '#374151',
  },
  dividerText: {
    color: '#9CA3AF',
    paddingHorizontal: 16,
    fontSize: 14,
    fontFamily: 'Poppins-Medium',
  },
  uploadButton: {
    backgroundColor: '#4B5563',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    gap: 8,
  },
  uploadButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
  },
  fileInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1F2937',
    padding: 12,
    borderRadius: 8,
    marginTop: 12,
    gap: 8,
  },
  fileName: {
    color: '#A5C3C4',
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    flex: 1,
  },
  previewImage: {
    width: 40,
    height: 40,
    borderRadius: 4,
  },
  cardSection: {
    marginTop: 32,
    alignItems: 'center',
  },
  card: {
    width: '100%',
    height: 280,
  },
  cardFace: {
    flex: 1,
    backgroundColor: '#2563EB',
    borderRadius: 16,
    padding: 24,
    paddingTop: 16,
    paddingBottom: 40,
    position: 'relative',
  },
  cardBack: {
    flex: 1,
    backgroundColor: '#059669',
    borderRadius: 16,
    padding: 24,
    paddingTop: 16,
    paddingBottom: 40,
    position: 'relative',
  },
  cardLabel: {
    color: '#93C5FD',
    fontSize: 12,
    fontFamily: 'Poppins-Medium',
    marginBottom: 8,
    letterSpacing: 1,
    textAlign: 'center',
  },
  cardContentWrapper: {
    flex: 1,
    marginTop: 8,
    marginBottom: 24,
  },
  cardScrollView: {
    flex: 1,
  },
  cardContentContainer: {
    flexGrow: 1,
    justifyContent: 'center',
  },
  cardText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontFamily: 'Sans',
    textAlign: 'center',
    lineHeight: 28,
    paddingHorizontal: 4,
  },
  tapHint: {
    position: 'absolute',
    bottom: 16,
    left: 0,
    right: 0,
    textAlign: 'center',
    color: '#93C5FD',
    fontSize: 12,
    fontFamily: 'Poppins-Regular',
    opacity: 0.8,
  },
  navigation: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 24,
    gap: 24,
  },
  navButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#1F2937',
  },
  navButtonDisabled: {
    opacity: 0.5,
  },
  cardCount: {
    color: '#9CA3AF',
    fontSize: 14,
    fontFamily: 'Poppins-Medium',
  },
});

export default FlashCardScreen;
