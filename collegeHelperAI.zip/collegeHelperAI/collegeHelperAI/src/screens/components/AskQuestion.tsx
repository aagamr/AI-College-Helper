import React, {useState} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  ScrollView,
  Image,
  Alert,
  ToastAndroid,
} from 'react-native';
import Clipboard from '@react-native-clipboard/clipboard';
import ReactMarkdown from 'react-native-markdown-display';
import {GoogleGenerativeAI} from '@google/generative-ai';

const AskQuestion = ({navigation}) => {
  const [question, setQuestion] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const apiKeys = [
    process.env.API_KEY1,
    process.env.API_KEY2,
    process.env.API_KEY3,
    process.env.API_KEY4,
    process.env.API_KEY5,
    process.env.API_KEY6,
  ];
  const selectedApiKey = apiKeys[Math.floor(Math.random() * apiKeys.length)];

  const handleCopyResponse = () => {
    try {
      Clipboard.setString(response);
      ToastAndroid.show('Response copied to clipboard', ToastAndroid.SHORT);
    } catch (error) {
      console.error('Error copying to clipboard:', error);
      Alert.alert('Failed to copy response');
    }
  };

  const handleAskQuestion = async () => {
    if (!question.trim()) {
      Alert.alert('Please enter a question.');
      return;
    }

    setLoading(true);
    try {
      if (selectedApiKey) {
        if (!selectedApiKey) {
          throw new Error('API key is not configured');
        }
        const genAI = new GoogleGenerativeAI(selectedApiKey);
        const model = genAI.getGenerativeModel({model: 'gemini-1.5-flash'});

        const result = await model.generateContent(question);
        const generatedText = result.response.text();
        console.log(generatedText);
        ToastAndroid.show(
          'Response Generated Successfully',
          ToastAndroid.SHORT,
        );
        setResponse(generatedText);
      }
    } catch (error) {
      console.error('Error asking question', error);
      Alert.alert('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.header}>
          <TouchableOpacity
            onPress={() => navigation.navigate('HomeTabs')}
            style={styles.backButton}>
            <Image
              resizeMode="contain"
              style={styles.backIcon}
              source={require('../../assets/images/left-arrow.png')}
            />
          </TouchableOpacity>
          <View style={styles.headerTextContainer}>
            <Text style={styles.title}>Ask a Question</Text>
            <Text style={styles.subtitle}>
              Get instant answers to your queries
            </Text>
          </View>
        </View>

        <View style={styles.inputSection}>
          <TextInput
            style={styles.input}
            placeholder="Type your question here..."
            placeholderTextColor="#9CA3AF"
            value={question}
            onChangeText={setQuestion}
            multiline
          />
          <TouchableOpacity
            style={[styles.askButton, loading && styles.askButtonDisabled]}
            onPress={handleAskQuestion}
            disabled={loading}>
            {loading ? (
              <ActivityIndicator color="#FFFFFF" />
            ) : (
              <Text style={styles.askButtonText}>
                {loading ? 'Asking...' : 'Ask Question'}
              </Text>
            )}
          </TouchableOpacity>
        </View>

        {response && (
          <View style={styles.responseContainer}>
            <View style={styles.responseHeader}>
              <Text style={styles.responseTitle}>Response</Text>
              <TouchableOpacity
                style={styles.copyButton}
                onPress={handleCopyResponse}>
                <Image
                  source={require('../../assets/images/copy.png')}
                  style={styles.copyIcon}
                  resizeMode="contain"
                />
              </TouchableOpacity>
            </View>
            <View style={styles.responseContent}>
              <ReactMarkdown style={styles.markdownStyle}>
                {response}
              </ReactMarkdown>
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  scrollContainer: {
    padding: 20,
  },
  header: {
    marginBottom: 32,
  },
  headerTextContainer: {
    alignItems: 'center',
    marginTop: 16,
  },
  backButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#1F2937',
    alignSelf: 'flex-start',
  },
  backIcon: {
    width: 24,
    height: 24,
    tintColor: '#FFFFFF',
  },
  title: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#F3F4F6',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    color: '#9CA3AF',
  },
  inputSection: {
    marginBottom: 24,
  },
  input: {
    backgroundColor: '#1F2937',
    color: '#F3F4F6',
    padding: 16,
    borderRadius: 12,
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#374151',
    minHeight: 120,
    textAlignVertical: 'top',
  },
  askButton: {
    backgroundColor: '#3B82F6',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  askButtonDisabled: {
    backgroundColor: '#6B7280',
  },
  askButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
  },
  responseContainer: {
    backgroundColor: '#1F2937',
    borderRadius: 12,
    padding: 16,
    marginTop: 24,
    borderWidth: 1,
    borderColor: '#374151',
  },
  responseHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  responseTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-Medium',
    color: '#F3F4F6',
  },
  copyButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#374151',
  },
  copyIcon: {
    width: 20,
    height: 20,
    tintColor: '#F3F4F6',
  },
  responseContent: {
    borderRadius: 8,
    padding: 16,
  },
  markdownStyle: {
    text: {
      color: '#F3F4F6',
      fontFamily: 'Poppins-Regular',
      fontSize: 16,
      lineHeight: 24,
    },
    heading1: {
      color: '#F3F4F6',
      fontSize: 24,
      fontFamily: 'Poppins-Bold',
      marginVertical: 16,
    },
    heading2: {
      color: '#F3F4F6',
      fontSize: 20,
      fontFamily: 'Poppins-Bold',
      marginVertical: 12,
    },
    strong: {
      fontFamily: 'Poppins-Bold',
      color: '#F3F4F6',
    },
    em: {},
    blockquote: {
      borderLeftWidth: 4,
      borderLeftColor: '#3B82F6',
      paddingLeft: 16,
      marginVertical: 8,
      color: '#9CA3AF',
    },
    code_inline: {
      backgroundColor: '#374151',
      color: '#3B82F6',
      padding: 4,
      borderRadius: 4,
      fontFamily: 'Poppins-Regular',
    },
    list_item: {
      marginVertical: 4,
    },
  },
});

export default AskQuestion;
