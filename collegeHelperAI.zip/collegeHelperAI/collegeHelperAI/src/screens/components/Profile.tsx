import React, {useContext} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Linking,
  Image,
  Share,
  ScrollView,
  Alert,
} from 'react-native';
import {UserContext} from '../../context/UserContext';
import auth from '@react-native-firebase/auth';

const Profile = ({navigation}) => {
  const {user} = useContext(UserContext);

  const handleOpenLink = url => {
    Linking.openURL(url).catch(err => console.error("Couldn't load page", err));
  };

  const handleLogout = async () => {
    try {
      await auth().signOut();
      // Navigate to your login/auth screen after logout
      navigation.reset({
        index: 0,
        routes: [{name: 'chooser'}], // Replace 'Login' with your auth screen name
      });
    } catch (error) {
      Alert.alert('Error', 'Failed to logout. Please try again.');
      console.error('Logout error:', error);
    }
  };

  const handleShare = async () => {
    try {
      const result = await Share.share({
        message:
          '🚀 Enhance your college life with the AI College Helper app! Get instant academic help and resources. Download now: https://play.google.com/store/apps/details?id=com.clg 📲',
      });
      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with specific activity
        } else {
          // shared successfully
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
      }
    } catch (error) {
      console.error('Error sharing the app', error);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {/* Header Section */}
        <View style={styles.header}>
          <View style={styles.headerTextContainer}>
            <Text style={styles.title}>Profile</Text>
            <Text style={styles.subtitle}>Manage your account</Text>
          </View>
        </View>

        {/* Profile Section */}
        <View style={styles.profileSection}>
          <Image style={styles.profileImage} source={{uri: user?.photoURL}} />
          <Text style={styles.name}>{user?.displayName || 'Hello 👋🏻'}</Text>
          <Text style={styles.email}>{user?.email}</Text>
        </View>

        {/* Social Links Section */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Follow Us on Socials</Text>
          <View style={styles.socialsContainer}>
            <TouchableOpacity
              style={styles.socialButton}
              onPress={() =>
                handleOpenLink('https://www.youtube.com/@khairexplains')
              }>
              <Image
                resizeMode="contain"
                style={styles.socialIcon}
                source={require('../../assets/images/youtube.png')}
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.socialButton}
              onPress={() =>
                handleOpenLink('https://www.linkedin.com/in/yogeshvashisth/')
              }>
              <Image
                resizeMode="contain"
                style={styles.socialIcon}
                source={require('../../assets/images/linkedin.png')}
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.socialButton}
              onPress={() => handleOpenLink('https://github.com/yogeshvas')}>
              <Image
                resizeMode="contain"
                style={styles.socialIcon}
                source={require('../../assets/images/github.png')}
              />
            </TouchableOpacity>
          </View>
        </View>

        {/* Share App Section */}
        <TouchableOpacity onPress={handleShare} style={styles.actionButton}>
          <Image
            resizeMode="contain"
            style={styles.actionIcon}
            source={require('../../assets/images/share.png')}
          />
          <Text style={styles.actionButtonText}>Share this App</Text>
        </TouchableOpacity>

        {/* Report Bug Section */}
        <TouchableOpacity
          onPress={() => handleOpenLink('https://forms.gle/tdYENA11XaBtF78h8')}
          style={[styles.actionButton, styles.bugReportButton]}>
          <Text style={styles.actionButtonText}>Report a Bug / Crash</Text>
        </TouchableOpacity>

        {/* Logout Button */}
        <TouchableOpacity
          onPress={handleLogout}
          style={[styles.actionButton, styles.logoutButton]}>
          <Text style={styles.actionButtonText}>Logout</Text>
        </TouchableOpacity>

        {/* Thanks Section */}
        <View style={styles.thanksSection}>
          <Text style={styles.thanksText}>Thanks for using this app!</Text>
          <Text style={styles.developerText}>- Yogesh Vashisth</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  scrollContainer: {
    padding: 20,
  },
  header: {
    marginBottom: 32,
  },
  headerTextContainer: {
    marginTop: 16,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#F3F4F6',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    color: '#9CA3AF',
  },
  profileSection: {
    alignItems: 'center',
    marginBottom: 32,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 3,
    borderColor: '#ffffff',
    marginBottom: 16,
  },
  name: {
    fontSize: 24,
    color: '#F3F4F6',
    fontFamily: 'Poppins-Bold',
    marginBottom: 4,
  },
  email: {
    fontSize: 16,
    color: '#9CA3AF',
    fontFamily: 'Poppins-Regular',
  },
  card: {
    backgroundColor: '#1F2937',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#374151',
  },
  cardTitle: {
    fontSize: 18,
    color: '#F3F4F6',
    fontFamily: 'Poppins-Medium',
    marginBottom: 16,
  },
  socialsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 24,
  },
  socialButton: {
    backgroundColor: '#374151',
    padding: 12,
    borderRadius: 12,
  },
  socialIcon: {
    width: 24,
    height: 24,
  },
  actionButton: {
    backgroundColor: '#1F2937',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    gap: 8,
    borderWidth: 1,
    borderColor: '#374151',
  },
  actionIcon: {
    width: 24,
    height: 24,
    tintColor: '#F3F4F6',
  },
  actionButtonText: {
    color: '#F3F4F6',
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
  },
  bugReportButton: {
    backgroundColor: '#DC2626',
    borderColor: '#DC2626',
  },
  logoutButton: {
    backgroundColor: '#4B5563',
    borderColor: '#4B5563',
  },
  thanksSection: {
    marginTop: 32,
    alignItems: 'center',
  },
  thanksText: {
    fontSize: 16,
    color: '#9CA3AF',
    fontFamily: 'Poppins-Regular',
    marginBottom: 4,
  },
  developerText: {
    fontSize: 16,
    color: '#60A5FA',
    fontFamily: 'Poppins-Medium',
  },
});

export default Profile;
