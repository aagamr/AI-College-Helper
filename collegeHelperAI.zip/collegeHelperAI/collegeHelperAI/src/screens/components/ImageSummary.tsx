import React, {useState} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ActivityIndicator,
  Image,
  ScrollView,
  TextInput,
} from 'react-native';
import DocumentPicker from 'react-native-document-picker';
import ImagePicker from 'react-native-image-crop-picker';
import {GoogleGenerativeAI} from '@google/generative-ai';
import RNFS from 'react-native-fs';
import Markdown from 'react-native-markdown-display';
import {Camera, Upload} from 'lucide-react-native';

const ImageSummary = ({navigation}) => {
  const [file, setFile] = useState(null);
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [prompt, setPrompt] = useState('');
  const apiKeys = [
    process.env.API_KEY1,
    process.env.API_KEY2,
    process.env.API_KEY3,
    process.env.API_KEY4,
    process.env.API_KEY5,
    process.env.API_KEY6,
  ];
  const selectedApiKey = apiKeys[Math.floor(Math.random() * apiKeys.length)];

  // Previous handlers remain the same
  const handleFilePick = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.images],
      });
      setFile(result[0]);
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
        console.log('User cancelled the picker');
      } else {
        throw err;
      }
    }
  };

  // Function to handle camera capture with cropping and editing
  const handleCameraCapture = async () => {
    try {
      const image = await ImagePicker.openCamera({
        cropping: true, // Enable cropping functionality
        compressImageQuality: 0.8, // Image quality
        includeBase64: true, // To get base64 for direct upload
        rotateEnabled: true, // Enable rotation functionality
      });

      setFile({
        uri: image.path,
        name: `photo_${Date.now()}.jpg`,
        type: image.mime,
      });
    } catch (err) {
      console.error('Error capturing image', err);
    }
  };

  const handleUpload = async () => {
    if (file) {
      setLoading(true);
      try {
        // Read the file and convert it to base64
        const base64File = await RNFS.readFile(file.uri, 'base64');
        // Set up Google Generative AI
        const genAI = new GoogleGenerativeAI(selectedApiKey || ''); // Provide empty string as fallback
        const model = genAI.getGenerativeModel({model: 'gemini-1.5-flash'});

        // Prepare the request
        const filePart = {
          inlineData: {
            data: base64File, // The base64-encoded file content
            mimeType: file.type, // MIME type of the file
          },
        };

        // Send the file and prompt to the AI model
        const mutatedPrompt =
          'Explain this image and give detailed explanation of it.' + prompt;
        const result = await model.generateContent([mutatedPrompt, filePart]);
        const generatedText = result.response.text();

        // Set the generated description
        setDescription(generatedText);
      } catch (error) {
        console.error('Error uploading file', error);
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.header}>
          <TouchableOpacity
            onPress={() => navigation.navigate('HomeTabs')}
            style={styles.backButton}>
            <Image
              resizeMode="contain"
              style={styles.backIcon}
              source={require('../../assets/images/left-arrow.png')}
            />
          </TouchableOpacity>
          <View style={styles.headerTextContainer}>
            <Text style={styles.title}>Image Explain</Text>
            <Text style={styles.subtitle}>
              Get detailed explanations of any image
            </Text>
          </View>
        </View>

        <View style={styles.inputSection}>
          <TextInput
            placeholder="Enter custom prompt (optional)"
            placeholderTextColor="#9CA3AF"
            style={styles.input}
            multiline
            value={prompt}
            onChangeText={setPrompt}
          />
        </View>

        <View style={styles.actionButtons}>
          <TouchableOpacity
            style={styles.uploadButton}
            onPress={handleFilePick}>
            <Upload color="#FFFFFF" size={24} />
            <Text style={styles.buttonText}>Pick an Image</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.cameraButton}
            onPress={handleCameraCapture}>
            <Camera color="#FFFFFF" size={24} />
          </TouchableOpacity>
        </View>

        {file && (
          <View style={styles.fileInfo}>
            <Text style={styles.fileName}>File: {file.name}</Text>
            <Image source={{uri: file.uri}} style={styles.previewImage} />
            <TouchableOpacity
              style={[
                styles.generateButton,
                loading && styles.generateButtonDisabled,
              ]}
              onPress={handleUpload}
              disabled={loading}>
              <Text style={styles.generateButtonText}>
                {loading ? 'Analyzing...' : 'Analyze Image'}
              </Text>
            </TouchableOpacity>
            {loading && <ActivityIndicator size="small" color="#3B82F6" />}
          </View>
        )}

        {description && (
          <View style={styles.summary}>
            <Text style={styles.summaryTitle}>Analysis Results:</Text>
            <Markdown style={markdownStyles}>{description}</Markdown>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  scrollContainer: {
    padding: 20,
  },
  header: {
    marginBottom: 32,
  },
  headerTextContainer: {
    alignItems: 'center',
    marginTop: 16,
  },
  backButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#1F2937',
    alignSelf: 'flex-start',
  },
  backIcon: {
    width: 24,
    height: 24,
    tintColor: '#FFFFFF',
  },
  title: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#F3F4F6',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    color: '#9CA3AF',
  },
  inputSection: {
    marginBottom: 24,
  },
  input: {
    backgroundColor: '#1F2937',
    color: '#F3F4F6',
    padding: 16,
    borderRadius: 12,
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#374151',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 24,
  },
  uploadButton: {
    flex: 1,
    backgroundColor: '#3B82F6',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    gap: 8,
  },
  cameraButton: {
    backgroundColor: '#4B5563',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    width: 56,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
  },
  fileInfo: {
    backgroundColor: '#1F2937',
    padding: 16,
    borderRadius: 12,
    marginBottom: 24,
    alignItems: 'center',
  },
  fileName: {
    color: '#9CA3AF',
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    marginBottom: 12,
  },
  previewImage: {
    width: 200,
    height: 200,
    borderRadius: 8,
    marginBottom: 16,
  },
  generateButton: {
    backgroundColor: '#3B82F6',
    padding: 16,
    borderRadius: 12,
    width: '100%',
    alignItems: 'center',
  },
  generateButtonDisabled: {
    backgroundColor: '#6B7280',
  },
  generateButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
  },
  summary: {
    backgroundColor: '#1F2937',
    padding: 16,
    borderRadius: 12,
    marginTop: 8,
  },
  summaryTitle: {
    color: '#F3F4F6',
    fontSize: 18,
    fontFamily: 'Poppins-Bold',
    marginBottom: 12,
  },
});

const markdownStyles = {
  body: {
    color: '#F3F4F6',
    fontFamily: 'Poppins-Regular',
    fontSize: 16,
    lineHeight: 24,
  },
  heading1: {
    color: '#F3F4F6',
    fontSize: 24,
    fontFamily: 'Poppins-Bold',
    marginBottom: 8,
    marginTop: 16,
  },
  heading2: {
    color: '#F3F4F6',
    fontSize: 20,
    fontFamily: 'Poppins-Bold',
    marginBottom: 8,
    marginTop: 16,
  },
  strong: {
    color: '#F3F4F6',
    fontFamily: 'Poppins-Bold',
  },
  em: {
    color: '#F3F4F6',
    fontStyle: 'italic',
  },
  blockquote: {
    borderLeftWidth: 4,
    borderLeftColor: '#3B82F6',
    paddingLeft: 16,
    marginVertical: 8,
    backgroundColor: '#1F2937',
  },
  code_inline: {
    backgroundColor: '#374151',
    color: '#3B82F6',
    padding: 4,
    borderRadius: 4,
    fontFamily: 'monospace',
  },
  list_item: {
    marginBottom: 8,
  },
};

export default ImageSummary;
