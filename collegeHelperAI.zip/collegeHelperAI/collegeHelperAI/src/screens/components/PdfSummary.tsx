import React, {useState} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ActivityIndicator,
  Image,
  ScrollView,
  TextInput,
} from 'react-native';
import DocumentPicker from 'react-native-document-picker';
import ReactMarkdown from 'react-native-markdown-display';
import RNFS from 'react-native-fs';
import {GoogleGenerativeAI} from '@google/generative-ai';
import {Upload, File} from 'lucide-react-native';

const PdfSummary = ({navigation}) => {
  const [file, setFile] = useState(null);
  const [summary, setSummary] = useState('');
  const [loading, setLoading] = useState(false);
  const [prompt, setPrompt] = useState('');
  const apiKeys = [
    process.env.API_KEY1,
    process.env.API_KEY2,
    process.env.API_KEY3,
    process.env.API_KEY4,
    process.env.API_KEY5,
    process.env.API_KEY6,
  ];
  const selectedApiKey = apiKeys[Math.floor(Math.random() * apiKeys.length)];

  const handleFilePick = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.allFiles, DocumentPicker.types.images],
      });
      setFile(result[0]);
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
        console.log('User cancelled the picker');
      } else {
        throw err;
      }
    }
  };

  const handleUpload = async () => {
    if (file) {
      setLoading(true);
      try {
        const base64File = await RNFS.readFile(file.uri, 'base64');
        const genAI = new GoogleGenerativeAI(selectedApiKey || '');
        const model = genAI.getGenerativeModel({model: 'gemini-1.5-flash'});

        const filePart = {
          inlineData: {
            data: base64File,
            mimeType: file.type,
          },
        };
        const mutatedPrompt =
          'This is a file, read this file and provide a detailed summary of file' +
          prompt;
        const result = await model.generateContent([mutatedPrompt, filePart]);
        const generatedText = result.response.text();

        setSummary(generatedText);
      } catch (error) {
        console.error('Error uploading file', error);
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.header}>
          <TouchableOpacity
            onPress={() => navigation.navigate('HomeTabs')}
            style={styles.backButton}>
            <Image
              resizeMode="contain"
              style={styles.backIcon}
              source={require('../../assets/images/left-arrow.png')}
            />
          </TouchableOpacity>
          <View style={styles.headerTextContainer}>
            <Text style={styles.title}>PDF Summary</Text>
            <Text style={styles.subtitle}>
              Get quick insights from your documents
            </Text>
          </View>
        </View>

        <View style={styles.inputSection}>
          <TextInput
            placeholder="Enter custom prompt (optional)"
            placeholderTextColor="#9CA3AF"
            style={styles.input}
            multiline
            value={prompt}
            onChangeText={setPrompt}
          />
        </View>

        <TouchableOpacity style={styles.uploadButton} onPress={handleFilePick}>
          <Upload color="#FFFFFF" size={24} />
          <Text style={styles.uploadButtonText}>Choose PDF File</Text>
        </TouchableOpacity>

        {file && (
          <View style={styles.fileInfo}>
            <File color="#A5C3C4" size={20} />
            <Text style={styles.fileName}>{file.name}</Text>
            {file.type.startsWith('image/') && (
              <Image source={{uri: file.uri}} style={styles.previewImage} />
            )}
            <TouchableOpacity
              style={[
                styles.generateButton,
                loading && styles.generateButtonDisabled,
              ]}
              onPress={handleUpload}
              disabled={loading}>
              <Text style={styles.generateButtonText}>
                {loading ? 'Generating Summary...' : 'Generate Summary'}
              </Text>
            </TouchableOpacity>
            {loading && (
              <ActivityIndicator
                style={styles.loader}
                size="small"
                color="#3B82F6"
              />
            )}
          </View>
        )}

        {summary && (
          <View style={styles.summaryContainer}>
            <Text style={styles.summaryTitle}>Summary</Text>
            <ReactMarkdown style={styles.markdownStyle}>
              {summary}
            </ReactMarkdown>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  scrollContainer: {
    padding: 20,
  },
  header: {
    marginBottom: 32,
  },
  headerTextContainer: {
    alignItems: 'center',
    marginTop: 16,
  },
  backButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#1F2937',
    alignSelf: 'flex-start',
  },
  backIcon: {
    width: 24,
    height: 24,
    tintColor: '#FFFFFF',
  },
  title: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#F3F4F6',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    color: '#9CA3AF',
  },
  inputSection: {
    marginBottom: 24,
  },
  input: {
    backgroundColor: '#1F2937',
    color: '#F3F4F6',
    padding: 16,
    borderRadius: 12,
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#374151',
  },
  uploadButton: {
    backgroundColor: '#4B5563',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    gap: 8,
    marginBottom: 16,
  },
  uploadButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
  },
  fileInfo: {
    backgroundColor: '#1F2937',
    padding: 16,
    borderRadius: 12,
    marginBottom: 24,
  },
  fileName: {
    color: '#A5C3C4',
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    marginVertical: 8,
  },
  previewImage: {
    width: 100,
    height: 100,
    borderRadius: 8,
    marginVertical: 8,
  },
  generateButton: {
    backgroundColor: '#3B82F6',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 12,
  },
  generateButtonDisabled: {
    backgroundColor: '#6B7280',
  },
  generateButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
  },
  loader: {
    marginTop: 12,
  },
  summaryContainer: {
    backgroundColor: '#1F2937',
    padding: 16,
    borderRadius: 12,
    marginTop: 8,
  },
  summaryTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-Bold',
    color: '#F3F4F6',
    marginBottom: 16,
  },
  markdownStyle: {
    body: {
      color: '#F3F4F6',
      fontFamily: 'Poppins-Regular',
      fontSize: 16,
      lineHeight: 24,
    },
    heading1: {
      color: '#F3F4F6',
      fontSize: 24,
      fontFamily: 'Poppins-Bold',
      marginVertical: 16,
    },
    heading2: {
      color: '#F3F4F6',
      fontSize: 20,
      fontFamily: 'Poppins-Bold',
      marginVertical: 12,
    },
    strong: {
      fontFamily: 'Poppins-Bold',
      color: '#F3F4F6',
    },
    em: {
      fontStyle: 'italic',
      color: '#F3F4F6',
    },
    blockquote: {
      borderLeftWidth: 4,
      borderLeftColor: '#3B82F6',
      paddingLeft: 16,
      marginVertical: 8,
      color: '#9CA3AF',
    },
    code_inline: {
      backgroundColor: '#374151',
      color: '#3B82F6',
      padding: 4,
      borderRadius: 4,
      fontFamily: 'Poppins-Regular',
    },
    list_item: {
      marginVertical: 4,
    },
  },
});

export default PdfSummary;
