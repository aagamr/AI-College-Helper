import React, {useState} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Image,
} from 'react-native';
import axios from 'axios';

const YoutubeSummary = ({navigation}) => {
  const [videoUrl, setVideoUrl] = useState('');
  const [transcript, setTranscript] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleGenerateTranscript = async () => {
    if (videoUrl) {
      setLoading(true);
      try {
        const response = await axios.post(
          'https://ai-college-helper-gemini-1.onrender.com/generate-transcript',
          {videoUrl},
        );
        setTranscript(response.data.transcript);
      } catch (error) {
        console.error('Error generating transcript', error);
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: 20,
        }}>
        <TouchableOpacity onPress={() => navigation.navigate('home')}>
          <Image
            resizeMode="contain"
            style={{width: 30, height: 30}}
            source={require('../../assets/images/left-arrow.png')}
          />
        </TouchableOpacity>
        <Text style={styles.title}>Video Transcript</Text>
      </View>
      <TextInput
        style={styles.input}
        placeholder="Enter YouTube Video URL"
        placeholderTextColor="#A5C3C4"
        value={videoUrl}
        onChangeText={setVideoUrl}
      />
      <TouchableOpacity
        style={styles.button}
        onPress={handleGenerateTranscript}
        disabled={loading}>
        <Text style={styles.buttonText}>
          {loading ? 'Generating...' : 'Generate Transcript'}
        </Text>
      </TouchableOpacity>
      {loading && <ActivityIndicator size="small" color="#76ABAE" />}
      {transcript && (
        <View style={styles.transcript}>
          <Text style={styles.transcriptTitle}>Transcript:</Text>
          <Text style={styles.transcriptText}>{transcript}</Text>
        </View>
      )}
    </SafeAreaView>
  );
};

export default YoutubeSummary;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#222831',
  },
  title: {
    fontSize: 28,
    color: '#EEEEEE',
    fontFamily: 'Space-Bold',
    textAlign: 'center',
  },
  input: {
    backgroundColor: '#393E46',
    color: '#EEEEEE',
    padding: 15,
    borderRadius: 10,
    fontSize: 18,
    marginBottom: 20,
    fontFamily: 'Space-Regular',
  },
  button: {
    backgroundColor: '#76ABAE',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 5,
  },
  buttonText: {
    color: '#fff',
    fontFamily: 'Space-Bold',
    fontSize: 18,
  },
  transcript: {
    marginTop: 20,
    padding: 15,
    backgroundColor: '#393E46',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 5,
  },
  transcriptTitle: {
    color: '#EEEEEE',
    fontFamily: 'Space-Bold',
    fontSize: 18,
    marginBottom: 10,
  },
  transcriptText: {
    color: '#EEEEEE',
    fontFamily: 'Space-Regular',
    fontSize: 16,
  },
});
