import React, {useState} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ActivityIndicator,
  Image,
  ScrollView,
} from 'react-native';
import DocumentPicker from 'react-native-document-picker';
import ReactMarkdown from 'react-native-markdown-display';
import RNFS from 'react-native-fs';
import {GoogleGenerativeAI} from '@google/generative-ai';
import {Upload, File} from 'lucide-react-native';

const PdfToQuiz = ({navigation}) => {
  const [file, setFile] = useState(null);
  const [summary, setSummary] = useState('');
  const [loading, setLoading] = useState(false);
  const apiKeys = [
    process.env.API_KEY1,
    process.env.API_KEY2,
    process.env.API_KEY3,
    process.env.API_KEY4,
    process.env.API_KEY5,
    process.env.API_KEY6,
  ];
  const selectedApiKey = apiKeys[Math.floor(Math.random() * apiKeys.length)];
  const handleFilePick = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.allFiles, DocumentPicker.types.images],
      });
      setFile(result[0]);
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
        console.log('User cancelled the picker');
      } else {
        throw err;
      }
    }
  };

  const handleUpload = async () => {
    if (file) {
      setLoading(true);
      try {
        const base64File = await RNFS.readFile(file.uri, 'base64');
        const genAI = new GoogleGenerativeAI(sy || '');
        const model = genAI.getGenerativeModel({model: 'gemini-1.5-flash'});

        const filePart = {
          inlineData: {
            data: base64File,
            mimeType: file.type,
          },
        };
        const prompt =
          'This is a file, read this file and Provide Top 10 Important Questions that are suitable for might come in examinations.';
        const result = await model.generateContent([prompt, filePart]);
        const generatedText = result.response.text();
        setSummary(generatedText);
      } catch (error) {
        console.error('Error uploading file', error);
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.header}>
          <TouchableOpacity
            onPress={() => navigation.navigate('HomeTabs')}
            style={styles.backButton}>
            <Image
              resizeMode="contain"
              style={styles.backIcon}
              source={require('../../assets/images/left-arrow.png')}
            />
          </TouchableOpacity>
          <View style={styles.headerTextContainer}>
            <Text style={styles.title}>PDF to Quiz</Text>
            <Text style={styles.subtitle}>
              Convert your documents into practice questions
            </Text>
          </View>
        </View>

        <View style={styles.uploadSection}>
          <TouchableOpacity
            style={styles.pickFileButton}
            onPress={handleFilePick}>
            <Upload color="#FFFFFF" size={24} />
            <Text style={styles.pickFileButtonText}>Select Document</Text>
          </TouchableOpacity>

          {file && (
            <View style={styles.fileInfoContainer}>
              <View style={styles.fileDetails}>
                <File color="#A5C3C4" size={20} />
                <Text style={styles.fileName}>{file.name}</Text>
              </View>
              {file.type.startsWith('image/') && (
                <Image source={{uri: file.uri}} style={styles.previewImage} />
              )}
              <TouchableOpacity
                style={[
                  styles.generateButton,
                  loading && styles.generateButtonDisabled,
                ]}
                onPress={handleUpload}
                disabled={loading}>
                {loading ? (
                  <ActivityIndicator color="#FFFFFF" />
                ) : (
                  <Text style={styles.generateButtonText}>
                    Generate Questions
                  </Text>
                )}
              </TouchableOpacity>
            </View>
          )}
        </View>

        {summary && (
          <View style={styles.quizContainer}>
            <Text style={styles.quizTitle}>Practice Questions</Text>
            <View style={styles.quizContent}>
              <ReactMarkdown
                style={{
                  body: styles.quizText,
                  strong: styles.quizBold,
                  list: styles.quizList,
                  listItem: styles.quizListItem,
                }}>
                {summary}
              </ReactMarkdown>
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  scrollContainer: {
    padding: 20,
  },
  header: {
    marginBottom: 32,
  },
  headerTextContainer: {
    alignItems: 'center',
    marginTop: 16,
  },
  backButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#1F2937',
    alignSelf: 'flex-start',
  },
  backIcon: {
    width: 24,
    height: 24,
    tintColor: '#FFFFFF',
  },
  title: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#F3F4F6',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    color: '#9CA3AF',
  },
  uploadSection: {
    marginBottom: 24,
  },
  pickFileButton: {
    backgroundColor: '#3B82F6',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    gap: 8,
  },
  pickFileButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
  },
  fileInfoContainer: {
    backgroundColor: '#1F2937',
    borderRadius: 12,
    padding: 16,
    marginTop: 16,
    borderWidth: 1,
    borderColor: '#374151',
  },
  fileDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  fileName: {
    color: '#E5E7EB',
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    flex: 1,
  },
  previewImage: {
    width: '100%',
    height: 200,
    borderRadius: 8,
    marginBottom: 12,
  },
  generateButton: {
    backgroundColor: '#059669',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  generateButtonDisabled: {
    backgroundColor: '#6B7280',
  },
  generateButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
  },
  quizContainer: {
    backgroundColor: '#1F2937',
    borderRadius: 12,
    padding: 16,
    marginTop: 24,
    borderWidth: 1,
    borderColor: '#374151',
  },
  quizTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-Medium',
    color: '#F3F4F6',
    marginBottom: 12,
  },
  quizContent: {
    backgroundColor: '#2D3748',
    borderRadius: 8,
    padding: 16,
  },
  quizText: {
    color: '#E5E7EB',
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    lineHeight: 24,
  },
  quizBold: {
    fontFamily: 'Poppins-Medium',
    color: '#F3F4F6',
  },
  quizList: {
    marginVertical: 8,
  },
  quizListItem: {
    marginLeft: 16,
  },
});

export default PdfToQuiz;
