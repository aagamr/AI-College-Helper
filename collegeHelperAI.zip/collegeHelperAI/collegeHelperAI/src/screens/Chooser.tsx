import {
  Alert,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';
import {GoogleSignin} from '@react-native-google-signin/google-signin';
import auth from '@react-native-firebase/auth';

const Chooser = ({navigation}: any) => {
  useEffect(() => {
    GoogleSignin.configure({
      webClientId:
        '919520424363-devnnij3ps074sneb9ir885cgeq4ib71.apps.googleusercontent.com',
    });
  });

  async function onGoogleButtonPress() {
    try {
      await GoogleSignin.hasPlayServices({showPlayServicesUpdateDialog: true});
      const userInfo = await GoogleSignin.signIn();
      const {idToken} = await GoogleSignin.getTokens();

      if (!idToken) {
        throw new Error('Google Sign-In failed: no ID token returned.');
      }

      const googleCredential = auth.GoogleAuthProvider.credential(idToken);
      await auth().signInWithCredential(googleCredential);
      navigation.navigate('HomeTabs');
    } catch (error) {
      Alert.alert('Error', error.message);
    }
  }
  return (
    <SafeAreaView style={styles.container}>
      <View>
        <View style={styles.header}>
          <Text style={styles.headerText}>#</Text>
        </View>
      </View>

      <View style={styles.row}>
        <View style={styles.textContainer}>
          <Text style={styles.peerText}>AI College</Text>
          <Text style={styles.connectText}>Helper.</Text>
        </View>
        <View style={styles.imageContainer}>
          <Image
            source={require('../assets/images/my-image.png')}
            style={styles.image}
          />
        </View>
      </View>

      <View style={styles.buttonRow}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.navigate('welcome')}>
          <Image
            style={styles.arrowImage}
            source={require('../assets/images/left-arrow.png')}
          />
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.googleButton}
          onPress={onGoogleButtonPress}>
          <View style={styles.googleButtonContent}>
            <Image
              style={styles.googleIcon}
              source={require('../assets/images/google.png')}
            />
            <Text style={styles.googleText}>Continue with Google</Text>
          </View>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

export default Chooser;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827', // Updated to match FlashCard dark background
    padding: 20,
    justifyContent: 'space-between',
  },
  header: {
    width: '100%',
    alignItems: 'flex-end',
    justifyContent: 'flex-end',
    flexDirection: 'row',
    marginBottom: 10,
  },
  headerText: {
    fontSize: 30,
    marginRight: 10,
    fontFamily: 'Space-SemiBold',
    color: '#F3F4F6', // Updated to lighter color for better contrast
  },
  row: {
    flexDirection: 'row',
  },
  textContainer: {
    width: '40%',
    marginVertical: 20,
  },
  peerText: {
    fontSize: 26,
    fontFamily: 'Space-Bold',
    color: '#F3F4F6', // Updated to match FlashCard text color
  },
  connectText: {
    fontSize: 40,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
  },
  imageContainer: {
    width: '60%',
  },
  image: {
    width: 400,
    height: 400,
    alignSelf: 'center',
    resizeMode: 'contain',
  },
  buttonRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  googleButton: {
    backgroundColor: '#2563EB', // Updated to match FlashCard primary button color
    borderRadius: 20,
    paddingVertical: 20,
    paddingHorizontal: 15,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    width: '80%',
    shadowColor: '#000000',
    shadowOffset: {width: 1, height: 1},
    shadowOpacity: 0.5,
    shadowRadius: 5,
    borderWidth: 2,
    borderColor: '#6b8fdd', // Updated border color to match theme
    elevation: 5,
  },
  googleButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  googleIcon: {
    width: 24,
    height: 24,
  },
  googleText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
    marginLeft: 10,
  },
  backButton: {
    width: 60,
    height: 60,
    backgroundColor: '#1F2937', // Updated to match FlashCard back button color
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#374151', // Updated border color to match theme
  },
  arrowImage: {
    width: 24,
    height: 24,
    tintColor: '#FFFFFF', // Added tintColor to make arrow icon white
  },
});
